//
//  YHProblemViewController.h
//  CarVideo
//
//  Created by Ethan.Luo on 2018/9/2.
//  Copyright © 2018年 Shanghai Yun Ye Shi Xun Technology Co. Ltd. All rights reserved.
//

#import "YHViewController.h"

@interface YHProblemViewController : YHViewController

@end
